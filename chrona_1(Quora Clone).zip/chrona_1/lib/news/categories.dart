class Categories {
  String image;
  String title;
  String newsType;

  Categories(String image, String title, String newsType) {
    this.image = image;
    this.title = title;
    this.newsType = newsType;
  }



}