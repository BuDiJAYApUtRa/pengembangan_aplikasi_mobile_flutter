class Strings {
  static String apiKey = "61f701e4186245a69b31cdd0e7dffaa1";
  static String country = "us";
}